package com.hearth;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class CreateOrJoinActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_or_join);

        // Start of declaration of buttons
        Button buttonCreate = findViewById(R.id.buttonCreate);
        Button buttonJoin = findViewById(R.id.buttonJoin);
        // End of declaration of buttons

        // Start of buttonCreate handler
        buttonCreate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intentCreateActivity = new Intent(CreateOrJoinActivity.this, CreateFamilyActivity.class);
                CreateOrJoinActivity.this.startActivity(intentCreateActivity);
            }
        });
        // End of buttonCreate handler

        // Start of buttonJoin handler
        buttonJoin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intentJoinActivity = new Intent(CreateOrJoinActivity.this, JoinFamilyActivity.class);
                CreateOrJoinActivity.this.startActivity(intentJoinActivity);
            }
        });
        // End of buttonJoin handler
    }
}