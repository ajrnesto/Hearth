package com.hearth;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.StrictMode;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class JoinFamilyActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_join_family);

        // Start of declaration of variables
        Connection cnnJoin = connectionClass();
        EditText editTextFamilyCode = findViewById(R.id.editTextFamilyCode);
        Button buttonJoinFamily = findViewById(R.id.buttonJoinFamily);
        // End of declaration of variables

        // Start of Logged in Email Retrieval
        SharedPreferences sharedPrefLoggedInEmail = getApplicationContext().getSharedPreferences("LoggedInEmail", MODE_PRIVATE);
        String loggedInEmail = sharedPrefLoggedInEmail.getString("LoggedInEmail", "Session expired");
        if (loggedInEmail == "Session expired"){
            // if for some reason the program cannot retrieve the email, then prompt the user to login again
            // clear all previous activities and open the missions page
            Intent intentLogInActivity = new Intent(JoinFamilyActivity.this, LoginActivity.class);
            intentLogInActivity.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            JoinFamilyActivity.this.startActivity(intentLogInActivity);
        }
        // End of Logged in Email Retrieval

        // Start of join button handler
        buttonJoinFamily.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String code = editTextFamilyCode.getText().toString();
                // check if user has not left the edittext as empty
                if (TextUtils.isEmpty(editTextFamilyCode.getText())){
                    errorDialog();
                }
                else{
                    // else, proceed to check if the entered code is existing
                    try{
                        // retrieve number of users with corresponding familycode
                        String qryJoin = "SELECT COUNT(*) FROM Users WHERE familycode = '"+code+"'";
                        Statement stmtJoin = cnnJoin.createStatement();
                        ResultSet resJoin = stmtJoin.executeQuery(qryJoin);
                        resJoin.next();
                        String strResRows = resJoin.getString(1);
                        int resRows = Integer.parseInt(strResRows);
                        if (resRows > 0){ // if code exists then,
                            // update user to have a family code but not an admin
                            try{
                                String qrySetFamilyCode = "UPDATE Users SET familycode = '"+code+"' WHERE email = '"+loggedInEmail+"'";
                                PreparedStatement stmtSetFamilyCode = cnnJoin.prepareStatement(qrySetFamilyCode);
                                int rows = stmtSetFamilyCode.executeUpdate();
                                if (rows > 0){
                                    // clear all previous activities and open the missions page
                                    Intent intentMissionsActivity = new Intent(JoinFamilyActivity.this, MissionsActivity.class);
                                    intentMissionsActivity.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                                    JoinFamilyActivity.this.startActivity(intentMissionsActivity);
                                }
                                else {
                                    Toast.makeText(getApplicationContext(), "Error updating user", Toast.LENGTH_SHORT).show();
                                }
                            }
                            catch (Exception exception){
                                Log.e("Error", exception.getMessage());
                            }
                        }
                        else{ // else if family code does not exist then output an error and let the user try again
                            errorCodeDoesNotExistDialog();
                            return;
                        }
                    } catch (SQLException throwables) {
                        throwables.printStackTrace();
                        System.out.println("Error ------------------------------------------ not connected");
                    }
                }
            }
        });
        // End of join button handler
    }

    // Start of Error Dialog Fragment Builder
    public void errorDialog() {
        String title = "Failed to Join Family";
        String message = "Family code could not be left empty";
        DialogFragment dialogFragment = new DialogFragment(title, message);
        dialogFragment.show(getSupportFragmentManager(), "Family Join Failed");
    }
    // End of Error Dialog Fragment Builder

    // Start of Error Dialog Fragment Builder
    public void errorCodeDoesNotExistDialog() {
        String title = "Failed to Join Family";
        String message = "Invalid Family Code entered";
        DialogFragment dialogFragment = new DialogFragment(title, message);
        dialogFragment.show(getSupportFragmentManager(), "Family Join Failed");
    }
    // End of Error Dialog Fragment Builder

    // Start of Connection Class Builder
    @SuppressLint("NewApi")
    public Connection connectionClass(){
        Connection con = null;
        String ip="192.168.1.7", port="1433", username="root", password="hearthkey", databasename="HearthDB";
        StrictMode.ThreadPolicy tp = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(tp);
        try{
            Class.forName("net.sourceforge.jtds.jdbc.Driver");
            String connectionUrl = "jdbc:jtds:sqlserver://"+ip+":"+port+";databasename="+databasename+";User="+username+";password="+password+";";
            con = DriverManager.getConnection(connectionUrl);
        }
        catch (Exception exception){
            Log.e("Error", exception.getMessage());
        }
        return con;
    }
    // End of Connection Class Builder
}