package com.hearth;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.os.StrictMode;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class LoginActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setRequestedOrientation (ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        setContentView(R.layout.activity_login);

        // Start of Declaration of Android Widgets
        EditText editTextEmailAddress = findViewById(R.id.editTextFamilyCode);
        EditText editTextPassword = findViewById(R.id.editTextPassword);
        Button buttonLogin = findViewById(R.id.buttonJoinFamily);
        Button buttonSignUp = findViewById(R.id.buttonSignUp);
        Connection cnnLogIn = connectionClass();
        // End of Declaration of Android Widgets

        // Start of Shared Preferences Initialization, check for default logged account
        SharedPreferences sharedPrefLoggedInEmail = getApplicationContext().getSharedPreferences("LoggedInEmail", MODE_PRIVATE);
        // For auto-login, check shared preferences local storage for previously logged in email
        String loggedInEmail = sharedPrefLoggedInEmail.getString("LoggedInEmail", null);
        if (loggedInEmail != null){ // if email exists in local storage,
            // clear all previous activities and then open the main activity
            Intent intentMainActivity = new Intent(LoginActivity.this, MissionsActivity.class);
            intentMainActivity.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            LoginActivity.this.startActivity(intentMainActivity);
        }
        // End of Shared Preferences Initialization

        // Start of Login Button Handler
        buttonLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Start of Retrieval of EditText Values
                String email = editTextEmailAddress.getText().toString().trim();
                String password = editTextPassword.getText().toString().trim();
                // End of Retrieval of EditText Values
                // Start of Form Validation
                if (TextUtils.isEmpty(email) || TextUtils.isEmpty(password)) {
                    // if edittexts are empty
                    errorDialog();
                    return;
                }
                else{
                    // else if edittexts are not empty
                    String result = "";
                    if (cnnLogIn != null){
                        try {
                            String qryLogin = "SELECT familycode FROM Users WHERE email = '"+email+"' AND password = '"+password+"'";
                            Statement stmtLogin = cnnLogIn.createStatement();
                            ResultSet resLogin = stmtLogin.executeQuery(qryLogin);
                            if(resLogin.next()) {
                                // if user exists, then locally save email as sharedpreference loggedinemail
                                sharedPrefLoggedInEmail.edit().putString("LoggedInEmail", email).apply();
                                // and then check if user already has family code
                                result = resLogin.getString(1);
                                if (result == null){
                                    // if user has no family code, then go to createorjoinfamily page
                                    Intent intentCreateOrJoinActivity = new Intent(LoginActivity.this, CreateOrJoinActivity.class);
                                    LoginActivity.this.startActivity(intentCreateOrJoinActivity);
                                }
                                else{

                                    /*---------------------------------------- change this to no longer check admin status at login
                                    // if user already has a family code, check if user is admin or not
                                    String qryIsUserAdmin = "SELECT isfamilyadmin FROM Users WHERE email = '"+email+"'";
                                    Statement stmtIsUserAdmin = cnnLogIn.createStatement();
                                    ResultSet resIsUserAdmin = stmtIsUserAdmin.executeQuery(qryIsUserAdmin);
                                    resIsUserAdmin.next();
                                    String isUserAdmin = resIsUserAdmin.getString(1);
                                    // then redirect the page according to their respective role
                                    if (isUserAdmin != null){ // value "1" = admin, value null = regular user
                                        // clear all previous activities and then open the missions page for admins
                                        Intent intentAdminMissionsActivity = new Intent(LoginActivity.this, MainAdminActivity.class);
                                        intentAdminMissionsActivity.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                                        LoginActivity.this.startActivity(intentAdminMissionsActivity);
                                    }
                                    else{
                                        // clear all previous activities and then open the missions page for member/regular users
                                        Intent intentMissionsActivity = new Intent(LoginActivity.this, MissionsActivity.class);
                                        intentMissionsActivity.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                                        LoginActivity.this.startActivity(intentMissionsActivity);
                                    }
                                    --------------------------------------------Instead, */
                                    // clear all previous activities and then open the main activity
                                    Intent intentMainActivity = new Intent(LoginActivity.this, MissionsActivity.class);
                                    intentMainActivity.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                                    LoginActivity.this.startActivity(intentMainActivity);
                                }
                            }
                            else{
                                Toast.makeText(getApplicationContext(), "User not found", Toast.LENGTH_SHORT).show();
                            }
                        } catch (SQLException throwables) {
                            throwables.printStackTrace();
                            System.out.println("Error ------------------------------------------ not connected");
                        }
                    }
                    else{
                        serverErrorDialog();
                    }
                }
                // End of Form Validation
            }
        });
        // End of Login Button Handler

        // Start of Sign up Button Handler
        buttonSignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intentSignUpActivity = new Intent(LoginActivity.this, SignUpActivity.class);
                LoginActivity.this.startActivity(intentSignUpActivity);
            }
        });
        // End of Sign up Button Handler
    }

    // Start of Dialog Fragment Builder
    public void errorDialog() {
        String title = "Login Failed";
        String message = "Please fill out all fields";
        DialogFragment dialogFragment = new DialogFragment(title, message);
        dialogFragment.show(getSupportFragmentManager(), "Login Failed");
    }
    // End of Dialog Fragment Builder

    // Start of Dialog Fragment Builder
    public void serverErrorDialog() {
        String title = "Servers are offline";
        String message = "Hearth servers are currently under maintenance. Please try again later.";
        DialogFragment dialogFragment = new DialogFragment(title, message);
        dialogFragment.show(getSupportFragmentManager(), "Server connection failed");
    }
    // End of Dialog Fragment Builder

    // Start of Connection Class Builder
    @SuppressLint("NewApi")
    public Connection connectionClass(){
        Connection con = null;
        String ip="192.168.1.7", port="1433", username="root", password="hearthkey", databasename="HearthDB";
        StrictMode.ThreadPolicy tp = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(tp);
        try{
            Class.forName("net.sourceforge.jtds.jdbc.Driver");
            String connectionUrl = "jdbc:jtds:sqlserver://"+ip+":"+port+";databasename="+databasename+";User="+username+";password="+password+";";
            con = DriverManager.getConnection(connectionUrl);
        }
        catch (Exception exception){
            Log.e("Error", exception.getMessage());
        }
        return con;
    }
    // End of Connection Class Builder
}