package com.hearth;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class MissionsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_missions);
    }
}