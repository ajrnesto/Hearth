package com.hearth;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.os.StrictMode;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class SignUpActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setRequestedOrientation (ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        setContentView(R.layout.activity_sign_up);

        // Start of Declaration of Android Widgets
        EditText editTextFirstName = findViewById(R.id.editTextFirstName);
        EditText editTextTextFamilyName = findViewById(R.id.editTextTextFamilyName);
        EditText editTextTextEmailAddress = findViewById(R.id.editTextTextEmailAddress);
        EditText editTextPassword = findViewById(R.id.editTextPassword);
        Button buttonSignUp = findViewById(R.id.buttonSignUp);
        Button buttonLogin = findViewById(R.id.buttonJoinFamily);
        // End of Declaration of Android Widgets

        // Start of Shared Preferences Initialization
        SharedPreferences sharedPrefLoggedInEmail = getApplicationContext().getSharedPreferences("LoggedInEmail", MODE_PRIVATE);
        // End of Shared Preferences Initialization

        // Start of Button Handler (Sign up Button)
        buttonSignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Connection cnnSignUp = connectionClass();
                try{
                    if (cnnSignUp != null){
                        // Start of Retrieval of EditText Values
                        String firstname = editTextFirstName.getText().toString().trim(),
                                familyname = editTextTextFamilyName.getText().toString().trim(),
                                email = editTextTextEmailAddress.getText().toString().trim(),
                                password = editTextPassword.getText().toString().trim();
                        // End of Retrieval of EditText Values
                        // Start of Form Validation
                        if (TextUtils.isEmpty(firstname) || TextUtils.isEmpty(familyname) || TextUtils.isEmpty(email) || TextUtils.isEmpty(password)){
                            signUpFailedDialog();
                            return;
                        }
                        else{
                            // Start of User Signup Query
                            String qrySignUp = "INSERT INTO Users(firstname, lastname, email, password) VALUES (?, ?, ?, ?)";
                            PreparedStatement stmtSignUp = cnnSignUp.prepareStatement(qrySignUp);
                            stmtSignUp.setString(1, firstname);
                            stmtSignUp.setString(2, familyname);
                            stmtSignUp.setString(3, email);
                            stmtSignUp.setString(4, password);

                            int rowsInserted = stmtSignUp.executeUpdate();
                            if (rowsInserted > 0){
                                // If sign up successful then
                                // then locally save email as sharedpreference
                                sharedPrefLoggedInEmail.edit().putString("LoggedInEmail", email).apply();
                                // and then go to create or join activity
                                Intent intentCreateOrJoinActivity = new Intent(SignUpActivity.this, CreateOrJoinActivity.class);
                                SignUpActivity.this.startActivity(intentCreateOrJoinActivity);
                            }
                            else{
                                Toast.makeText(getApplicationContext(), "Unknown Error when trying to Sign Up", Toast.LENGTH_LONG).show();
                            }
                            // End of User Signup Query
                        }
                        // End of Form Validation
                    }
                }
                catch (Exception exception){
                    Log.e("Error", exception.getMessage());
                }
            }
        });
        // End of Button Handler (Sign up Button)

        // Start of Button Handler (Log in TextView Button)
        buttonLogin.setOnClickListener(view -> {
            finish();
        });
        // End of Button Handler (Log in TextView Button)
    }

    // Start of Connection Class Builder
    @SuppressLint("NewApi")
    public Connection connectionClass(){
        Connection con = null;
        String ip="192.168.1.7", port="1433", username="root", password="hearthkey", databasename="HearthDB";
        StrictMode.ThreadPolicy tp = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(tp);
        try{
            Class.forName("net.sourceforge.jtds.jdbc.Driver");
            String connectionUrl = "jdbc:jtds:sqlserver://"+ip+":"+port+";databasename="+databasename+";User="+username+";password="+password+";";
            con = DriverManager.getConnection(connectionUrl);
        }
        catch (Exception exception){
            Log.e("Error", exception.getMessage());
        }
        return con;
    }
    // End of Connection Class Builder

    // Start of Dialog Fragment Builder
    public void signUpFailedDialog() {
        String title = "Signing up Failed";
        String message = "Please fill out all fields";
        DialogFragment dialogFragment = new DialogFragment(title, message);
        dialogFragment.show(getSupportFragmentManager(), "Signing up Failed");
    }
    // End of Dialog Fragment Builder
}